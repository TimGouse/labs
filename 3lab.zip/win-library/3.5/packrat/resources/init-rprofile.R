#### -- Packrat Autoloader (version 0.9.1-1) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
